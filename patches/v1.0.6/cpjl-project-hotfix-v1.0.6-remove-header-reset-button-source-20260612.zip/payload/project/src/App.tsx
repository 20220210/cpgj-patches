import { useState, useCallback, useEffect, useRef } from 'react';
import type { ReactNode } from 'react';
import type { AppStore } from './types';
import {
  createEmptyStore,
  hasLocalStoreCache,
  loadInitialStore,
  loadStore,
  normalizeStore,
  saveStore,
} from './store';
import {
  clearSession,
  createStoreCacheKey,
  fetchCurrentSession,
  isSystemAdminRole,
  loadSavedSession,
  login,
  logout,
  roleLabel,
} from './store/authStore';
import type { ApiSession } from './store/authStore';
import { ApiRequestError, fetchServerStore, importServerStore, openRealtimeStream, persistServerStore } from './store/serverStore';
import Projects from './sections/Projects';
import TemplateManager from './sections/TemplateManager';
import UserManagement from './sections/UserManagement';
import SystemUpgrade from './sections/SystemUpgrade';
import { notify } from './utils/feedback';
import './App.css';

type Tab = 'templates' | 'projects' | 'users' | 'upgrade';

const TAB_STORAGE_KEY = 'cpjl:last-tab';
const TAB_HASH_PREFIX = 'tab=';
const validTabs = new Set<Tab>(['projects', 'templates', 'users', 'upgrade']);
const APP_VERSION = 'v1.0.6';

function normalizeTab(value: string | null | undefined): Tab | null {
  if (!value) return null;
  const cleaned = value.trim().replace(/^#\/?/, '').replace(/^\/?/, '');
  const tabValue = cleaned.startsWith(TAB_HASH_PREFIX) ? cleaned.slice(TAB_HASH_PREFIX.length) : cleaned;
  return validTabs.has(tabValue as Tab) ? tabValue as Tab : null;
}

function readInitialTab(): Tab {
  if (typeof window === 'undefined') return 'projects';
  return normalizeTab(window.location.hash) || normalizeTab(window.localStorage.getItem(TAB_STORAGE_KEY)) || 'projects';
}

function persistTab(tab: Tab) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(TAB_STORAGE_KEY, tab);
  const nextHash = `#${TAB_HASH_PREFIX}${tab}`;
  if (window.location.hash !== nextHash) {
    window.history.replaceState(null, '', `${window.location.pathname}${window.location.search}${nextHash}`);
  }
}

function backupFileName() {
  const stamp = new Date().toISOString().slice(0, 10);
  return `cpjl-backup-${stamp}.json`;
}

export default function App() {
  const [session, setSession] = useState<ApiSession | null>(() => loadSavedSession());
  const [isAuthReady, setIsAuthReady] = useState(false);
  const [initialStore, setInitialStore] = useState<AppStore | null>(null);
  const [store, setStore] = useState<AppStore | null>(null);
  const [tab, setTabState] = useState<Tab>(() => readInitialTab());
  const [pageActions, setPageActions] = useState<ReactNode | null>(null);
  const importInputRef = useRef<HTMLInputElement | null>(null);
  const saveTimerRef = useRef<number | null>(null);
  const pendingServerStoreRef = useRef<AppStore | null>(null);
  const saveInFlightRef = useRef(false);
  const serverRevisionRef = useRef<number | null>(null);
  const userEditedBeforeServerLoadRef = useRef(false);

  const cacheKey = session ? createStoreCacheKey(session) : null;
  const sessionToken = session?.token ?? null;
  const isAdmin = isSystemAdminRole(session?.user.role);

  const setTab = useCallback((nextTab: Tab) => {
    setTabState(nextTab);
    persistTab(nextTab);
  }, []);

  useEffect(() => {
    persistTab(tab);
  }, [tab]);

  useEffect(() => {
    if (session && !isAdmin && tab !== 'projects') setTab('projects');
  }, [isAdmin, session, setTab, tab]);

  const flushServerSave = useCallback(function flushServerSaveNow() {
    if (!session || saveInFlightRef.current || !pendingServerStoreRef.current) return;

    const nextStore = pendingServerStoreRef.current;
    pendingServerStoreRef.current = null;
    saveInFlightRef.current = true;
    let retryLater = false;

    void persistServerStore(session, nextStore, serverRevisionRef.current)
      .then(result => {
        serverRevisionRef.current = result.revision ?? serverRevisionRef.current;
      })
      .catch(error => {
        if (error instanceof ApiRequestError && error.status === 409) {
          notify('服务端数据已被其他用户更新，请刷新后再修改模板');
        }

        retryLater = true;
        pendingServerStoreRef.current = pendingServerStoreRef.current ?? nextStore;
      })
      .finally(() => {
        saveInFlightRef.current = false;
        if (!pendingServerStoreRef.current) return;
        if (retryLater) {
          if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current);
          saveTimerRef.current = window.setTimeout(flushServerSaveNow, 2000);
          return;
        }
        flushServerSaveNow();
      });
  }, [session]);

  const scheduleServerSave = useCallback((nextStore: AppStore, delay = 500) => {
    pendingServerStoreRef.current = nextStore;
    if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current);
    saveTimerRef.current = window.setTimeout(flushServerSave, delay);
  }, [flushServerSave]);

  useEffect(() => {
    if (!sessionToken) {
      setIsAuthReady(true);
      setInitialStore(null);
      setStore(null);
      return;
    }

    setIsAuthReady(false);
    void fetchCurrentSession(sessionToken)
      .then(user => setSession(current => current ? { ...current, user } : current))
      .catch(() => {
        clearSession({ clearStoreCache: true });
        setSession(null);
      })
      .finally(() => setIsAuthReady(true));
  }, [sessionToken]);

  useEffect(() => {
    if (!session || !isAuthReady || !cacheKey) return;
    let isMounted = true;
    userEditedBeforeServerLoadRef.current = false;

    const loadBaseStore = session.user.role === 'admin'
      ? loadInitialStore()
      : Promise.resolve(createEmptyStore());

    void loadBaseStore.then(baseStore => {
      if (!isMounted) return;
      const hasRoleCache = hasLocalStoreCache(cacheKey);
      const hasLegacyCache = session.user.role === 'admin' && hasLocalStoreCache();
      const hasLocalCache = hasRoleCache || hasLegacyCache;
      const localStore = hasRoleCache || session.user.role !== 'admin'
        ? loadStore(baseStore, cacheKey)
        : loadStore(baseStore);
      setInitialStore(baseStore);
      setStore(localStore);

      void fetchServerStore(session)
        .then(serverResponse => {
          if (!isMounted) return;
          serverRevisionRef.current = serverResponse.revision ?? null;
          const serverStore = serverResponse.store;
          if (serverStore) {
            const normalizedServerStore = normalizeStore(serverStore, baseStore);
            if (!userEditedBeforeServerLoadRef.current) {
              setStore(normalizedServerStore);
              saveStore(normalizedServerStore, baseStore, cacheKey);
              return;
            }
          }
          if ((hasLocalCache || session.user.role === 'admin') && !userEditedBeforeServerLoadRef.current) {
            scheduleServerSave(localStore, 0);
          }
        })
        .catch(() => {
          // The local cache is already rendered; background sync can recover later.
        });
    });

    return () => {
      isMounted = false;
      if (saveTimerRef.current) window.clearTimeout(saveTimerRef.current);
    };
  }, [cacheKey, isAuthReady, scheduleServerSave, session]);

  useEffect(() => {
    if (!session || !isAuthReady || !initialStore || !cacheKey) return;
    const source = openRealtimeStream(session, event => {
      if (event.actor?.username === session.user.username) return;
      if (event.type !== 'store.updated' && event.type !== 'templates.updated') return;
      void fetchServerStore(session)
        .then(serverResponse => {
          serverRevisionRef.current = serverResponse.revision ?? serverRevisionRef.current;
          const normalizedServerStore = normalizeStore(serverResponse.store, initialStore);
          setStore(normalizedServerStore);
          saveStore(normalizedServerStore, initialStore, cacheKey);
        })
        .catch(() => undefined);
    });
    return () => source.close();
  }, [cacheKey, initialStore, isAuthReady, session]);

  const updateStore = useCallback((updater: (prev: AppStore) => AppStore) => {
    if (!initialStore || !cacheKey) return;
    userEditedBeforeServerLoadRef.current = true;
    setStore(prev => {
      if (!prev) return prev;
      const next = normalizeStore(updater(prev), initialStore);
      saveStore(next, initialStore, cacheKey);
      if (session?.user.role === 'admin' && tab !== 'projects') scheduleServerSave(next);
      return next;
    });
  }, [cacheKey, initialStore, scheduleServerSave, session?.user.role, tab]);

  async function handleLogin(username: string, password: string) {
    const nextSession = await login(username, password);
    userEditedBeforeServerLoadRef.current = false;
    setTab('projects');
    setSession(nextSession);
  }

  async function handleLogout() {
    if (!session) return;
    try {
      await logout(session.token);
    } catch {
      clearSession({ clearStoreCache: true });
    }
    setSession(null);
    setInitialStore(null);
    setStore(null);
    pendingServerStoreRef.current = null;
    setTab('projects');
  }

  function handleExportBackup() {
    if (!store || !initialStore || !isAdmin) return;
    const blob = new Blob([JSON.stringify(normalizeStore(store, initialStore), null, 2)], {
      type: 'application/json;charset=utf-8',
    });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = backupFileName();
    link.click();
    URL.revokeObjectURL(url);
  }

  async function handleImportBackup(file: File | null) {
    if (!file || !initialStore || !session || !isAdmin || !cacheKey) return;
    try {
      const imported = normalizeStore(JSON.parse(await file.text()) as Partial<AppStore>, initialStore);
      userEditedBeforeServerLoadRef.current = true;
      setStore(imported);
      saveStore(imported, initialStore, cacheKey);
      void importServerStore(session, imported, serverRevisionRef.current)
        .then(result => { serverRevisionRef.current = result.revision ?? serverRevisionRef.current; })
        .catch(() => scheduleServerSave(imported, 0));
      notify('数据已导入');
    } catch {
      notify('导入失败，请确认文件是有效的 CPJL 备份 JSON');
    } finally {
      if (importInputRef.current) importInputRef.current.value = '';
    }
  }

  if (!session) return <LoginScreen onLogin={handleLogin} />;

  if (!isAuthReady || !store || !initialStore) {
    return (
      <div className="app-root">
        <div className="empty-state" style={{ margin: 'auto' }}>
          <div className="empty-state-text">正在加载数据...</div>
        </div>
      </div>
    );
  }

  return (
    <div className="app-root">
      <header className="app-header">
        <div className="app-logo">
          <span className="logo-badge">{APP_VERSION}</span>
          <span className="logo-title">测评记录编写工具</span>
        </div>
        <div className="header-page-actions" aria-label="当前页面功能">
          {pageActions}
        </div>
        <nav className="app-nav">
          <button
            className={`nav-btn${tab === 'projects' ? ' active' : ''}`}
            onClick={() => setTab('projects')}
          >
            项目目录
          </button>
          {isAdmin && (
            <>
              <button
                className={`nav-btn${tab === 'templates' ? ' active' : ''}`}
                onClick={() => setTab('templates')}
              >
                模板管理
              </button>
              <button
                className={`nav-btn${tab === 'users' ? ' active' : ''}`}
                onClick={() => setTab('users')}
              >
                用户管理
              </button>
              <button
                className={`nav-btn${tab === 'upgrade' ? ' active' : ''}`}
                onClick={() => setTab('upgrade')}
              >
                系统管理
              </button>
            </>
          )}
        </nav>
        <div className="app-tools">
          <span className="session-badge">{session.user.username} · {roleLabel(session.user.role)}</span>
          {isAdmin && (
            <>
              <button className="btn btn-default btn-sm" onClick={handleExportBackup}>导出备份</button>
              <button className="btn btn-default btn-sm" onClick={() => importInputRef.current?.click()}>导入备份</button>
            </>
          )}
          <button className="btn btn-default btn-sm" onClick={() => void handleLogout()}>退出</button>
          <input
            ref={importInputRef}
            type="file"
            accept="application/json,.json"
            hidden
            onChange={e => void handleImportBackup(e.target.files?.[0] ?? null)}
          />
        </div>
      </header>

      <main className="app-main">
        {tab === 'projects' && (
          <Projects store={store} updateStore={updateStore} session={session} role={session.user.role} onPageActionsChange={setPageActions} />
        )}
        {tab === 'templates' && isAdmin && (
          <TemplateManager store={store} updateStore={updateStore} session={session} onPageActionsChange={setPageActions} />
        )}
        {tab === 'users' && isAdmin && (
          <UserManagement session={session} onPageActionsChange={setPageActions} />
        )}
        {tab === 'upgrade' && isAdmin && (
          <SystemUpgrade session={session} onPageActionsChange={setPageActions} />
        )}
      </main>
    </div>
  );
}

interface LoginScreenProps {
  onLogin: (username: string, password: string) => Promise<void>;
}

function LoginScreen({ onLogin }: LoginScreenProps) {
  const [username, setUsername] = useState('admin');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  async function submit() {
    if (!username.trim() || !password) {
      setError('请输入账号和密码');
      return;
    }
    setIsSubmitting(true);
    setError('');
    try {
      await onLogin(username.trim(), password);
    } catch (loginError) {
      setError(loginError instanceof Error ? loginError.message : '登录失败');
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <div className="app-root auth-root">
      <div className="auth-panel">
        <div className="app-logo auth-logo">
          <span className="logo-badge">{APP_VERSION}</span>
          <span className="logo-title">测评记录编写工具</span>
        </div>
        <div className="form-group">
          <label className="form-label required">账号</label>
          <input
            className="form-input"
            autoFocus
            value={username}
            onChange={event => setUsername(event.target.value)}
            onKeyDown={event => event.key === 'Enter' && void submit()}
          />
        </div>
        <div className="form-group">
          <label className="form-label required">密码</label>
          <input
            className="form-input"
            type="password"
            value={password}
            onChange={event => setPassword(event.target.value)}
            onKeyDown={event => event.key === 'Enter' && void submit()}
          />
        </div>
        {error && <div className="auth-error">{error}</div>}
        <button className="btn btn-primary auth-submit" disabled={isSubmitting} onClick={() => void submit()}>
          {isSubmitting ? '登录中...' : '登录'}
        </button>
      </div>
    </div>
  );
}
