# v1.0.6：移除右上角重置按钮

## 变更说明

- 移除系统右上角管理员工具区的“重置”按钮。
- 移除前端 `handleResetData` 入口和 `resetServerStore` 前端调用。
- 保留“导出备份”“导入备份”“退出”按钮。
- 不修改后端 `/api/store/reset` 接口，不修改数据库结构，不修改升级、备份和 GitHub 同步服务。

## 验证

```text
npm run build: passed
grep 重置/handleResetData/resetServerStore in src/App.tsx and dist: no matches
```

## 回滚

恢复 v1.0.5/v1.0.4 对应的 `src/App.tsx` 和 `dist` 前端产物即可。
