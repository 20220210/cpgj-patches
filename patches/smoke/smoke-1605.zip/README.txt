CPGJ GitHub remote-pull ZIP smoke test
version: v1.0.4
generated_by: ChatGPT
purpose: verify GitHub raw zip -> AI FileBox pull -> SJ
timestamp_utc: 2026-06-12T08:05:00Z
